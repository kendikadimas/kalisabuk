import PostController from './PostController'
import PotentialController from './PotentialController'
import InstitutionController from './InstitutionController'
import DemographicController from './DemographicController'
import DevelopmentController from './DevelopmentController'
import ServiceTypeController from './ServiceTypeController'
import ServiceRequestController from './ServiceRequestController'
import VillageOfficialController from './VillageOfficialController'
import VillageStatController from './VillageStatController'
import AnnouncementController from './AnnouncementController'
import UserController from './UserController'
const Admin = {
    PostController: Object.assign(PostController, PostController),
PotentialController: Object.assign(PotentialController, PotentialController),
InstitutionController: Object.assign(InstitutionController, InstitutionController),
DemographicController: Object.assign(DemographicController, DemographicController),
DevelopmentController: Object.assign(DevelopmentController, DevelopmentController),
ServiceTypeController: Object.assign(ServiceTypeController, ServiceTypeController),
ServiceRequestController: Object.assign(ServiceRequestController, ServiceRequestController),
VillageOfficialController: Object.assign(VillageOfficialController, VillageOfficialController),
VillageStatController: Object.assign(VillageStatController, VillageStatController),
AnnouncementController: Object.assign(AnnouncementController, AnnouncementController),
UserController: Object.assign(UserController, UserController),
}

export default Admin