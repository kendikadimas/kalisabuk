import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
export const home = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})

home.definition = {
    methods: ["get","head"],
    url: '/',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
home.url = (options?: RouteQueryOptions) => {
    return home.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
home.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: home.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
home.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: home.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
    const homeForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: home.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
        homeForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::home
 * @see app/Http/Controllers/PublicController.php:22
 * @route '/'
 */
        homeForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: home.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    home.form = homeForm
/**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
export const profile = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})

profile.definition = {
    methods: ["get","head"],
    url: '/profile',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
profile.url = (options?: RouteQueryOptions) => {
    return profile.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
profile.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: profile.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
profile.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: profile.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
    const profileForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: profile.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
        profileForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::profile
 * @see app/Http/Controllers/PublicController.php:44
 * @route '/profile'
 */
        profileForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: profile.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    profile.form = profileForm
/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
export const potentials = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentials.url(options),
    method: 'get',
})

potentials.definition = {
    methods: ["get","head"],
    url: '/potentials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
potentials.url = (options?: RouteQueryOptions) => {
    return potentials.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
potentials.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: potentials.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
potentials.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: potentials.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
    const potentialsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: potentials.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
        potentialsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentials.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::potentials
 * @see app/Http/Controllers/PublicController.php:53
 * @route '/potentials'
 */
        potentialsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: potentials.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    potentials.form = potentialsForm
/**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
export const data = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})

data.definition = {
    methods: ["get","head"],
    url: '/data',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
data.url = (options?: RouteQueryOptions) => {
    return data.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
data.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: data.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
data.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: data.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
    const dataForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: data.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
        dataForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::data
 * @see app/Http/Controllers/PublicController.php:60
 * @route '/data'
 */
        dataForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: data.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    data.form = dataForm
/**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
export const institutions = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: institutions.url(options),
    method: 'get',
})

institutions.definition = {
    methods: ["get","head"],
    url: '/institutions',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
institutions.url = (options?: RouteQueryOptions) => {
    return institutions.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
institutions.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: institutions.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
institutions.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: institutions.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
    const institutionsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: institutions.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
        institutionsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: institutions.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::institutions
 * @see app/Http/Controllers/PublicController.php:68
 * @route '/institutions'
 */
        institutionsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: institutions.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    institutions.form = institutionsForm
/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
export const news = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})

news.definition = {
    methods: ["get","head"],
    url: '/news',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
news.url = (options?: RouteQueryOptions) => {
    return news.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
news.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: news.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
news.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: news.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
    const newsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: news.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
        newsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: news.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::news
 * @see app/Http/Controllers/PublicController.php:75
 * @route '/news'
 */
        newsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: news.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    news.form = newsForm
/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
export const newsShow = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})

newsShow.definition = {
    methods: ["get","head"],
    url: '/news/{slug}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
newsShow.url = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { slug: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    slug: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        slug: args.slug,
                }

    return newsShow.definition.url
            .replace('{slug}', parsedArgs.slug.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
newsShow.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: newsShow.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
newsShow.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: newsShow.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
    const newsShowForm = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: newsShow.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
        newsShowForm.get = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: newsShow.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\PublicController::newsShow
 * @see app/Http/Controllers/PublicController.php:82
 * @route '/news/{slug}'
 */
        newsShowForm.head = (args: { slug: string | number } | [slug: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: newsShow.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    newsShow.form = newsShowForm
const PublicController = { home, profile, potentials, data, institutions, news, newsShow }

export default PublicController