import PublicController from './PublicController'
import Public from './Public'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    PublicController: Object.assign(PublicController, PublicController),
Public: Object.assign(Public, Public),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers