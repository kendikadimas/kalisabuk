import DevelopmentController from './DevelopmentController'
import ServiceController from './ServiceController'
const Public = {
    DevelopmentController: Object.assign(DevelopmentController, DevelopmentController),
ServiceController: Object.assign(ServiceController, ServiceController),
}

export default Public