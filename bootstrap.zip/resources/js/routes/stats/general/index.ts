import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:21
 * @route '/dashboard/stats/general'
 */
export const update = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

update.definition = {
    methods: ["post"],
    url: '/dashboard/stats/general',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:21
 * @route '/dashboard/stats/general'
 */
update.url = (options?: RouteQueryOptions) => {
    return update.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:21
 * @route '/dashboard/stats/general'
 */
update.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: update.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:21
 * @route '/dashboard/stats/general'
 */
    const updateForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\DemographicController::update
 * @see app/Http/Controllers/Admin/DemographicController.php:21
 * @route '/dashboard/stats/general'
 */
        updateForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(options),
            method: 'post',
        })
    
    update.form = updateForm
const general = {
    update: Object.assign(update, update),
}

export default general