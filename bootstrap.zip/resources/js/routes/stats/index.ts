import general from './general'
const stats = {
    general: Object.assign(general, general),
}

export default stats