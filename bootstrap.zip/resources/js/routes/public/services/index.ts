import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/layanan',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ServiceController::index
 * @see app/Http/Controllers/Public/ServiceController.php:14
 * @route '/layanan'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Public\ServiceController::store
 * @see app/Http/Controllers/Public/ServiceController.php:21
 * @route '/layanan'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/layanan',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Public\ServiceController::store
 * @see app/Http/Controllers/Public/ServiceController.php:21
 * @route '/layanan'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ServiceController::store
 * @see app/Http/Controllers/Public/ServiceController.php:21
 * @route '/layanan'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Public\ServiceController::store
 * @see app/Http/Controllers/Public/ServiceController.php:21
 * @route '/layanan'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Public\ServiceController::store
 * @see app/Http/Controllers/Public/ServiceController.php:21
 * @route '/layanan'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
export const success = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})

success.definition = {
    methods: ["get","head"],
    url: '/layanan/sukses/{ticket_code}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
success.url = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket_code: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket_code: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket_code: args.ticket_code,
                }

    return success.definition.url
            .replace('{ticket_code}', parsedArgs.ticket_code.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
success.get = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: success.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
success.head = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: success.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
    const successForm = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: success.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
        successForm.get = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Public\ServiceController::success
 * @see app/Http/Controllers/Public/ServiceController.php:50
 * @route '/layanan/sukses/{ticket_code}'
 */
        successForm.head = (args: { ticket_code: string | number } | [ticket_code: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: success.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    success.form = successForm
const services = {
    index: Object.assign(index, index),
store: Object.assign(store, store),
success: Object.assign(success, success),
}

export default services