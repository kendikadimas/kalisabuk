import developments from './developments'
import services from './services'
const publicMethod = {
    developments: Object.assign(developments, developments),
services: Object.assign(services, services),
}

export default publicMethod