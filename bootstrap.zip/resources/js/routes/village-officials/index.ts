import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/dashboard/village-officials',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::index
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:16
 * @route '/dashboard/village-officials'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/dashboard/village-officials/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::create
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:28
 * @route '/dashboard/village-officials/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:36
 * @route '/dashboard/village-officials'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/dashboard/village-officials',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:36
 * @route '/dashboard/village-officials'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:36
 * @route '/dashboard/village-officials'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:36
 * @route '/dashboard/village-officials'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::store
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:36
 * @route '/dashboard/village-officials'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
export const show = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/dashboard/village-officials/{village_official}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
show.url = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { village_official: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    village_official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        village_official: args.village_official,
                }

    return show.definition.url
            .replace('{village_official}', parsedArgs.village_official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
show.get = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
show.head = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
    const showForm = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
        showForm.get = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::show
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:74
 * @route '/dashboard/village-officials/{village_official}'
 */
        showForm.head = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
export const edit = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/dashboard/village-officials/{village_official}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
edit.url = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { village_official: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    village_official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        village_official: args.village_official,
                }

    return edit.definition.url
            .replace('{village_official}', parsedArgs.village_official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
edit.get = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
edit.head = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
    const editForm = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
        editForm.get = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::edit
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:84
 * @route '/dashboard/village-officials/{village_official}/edit'
 */
        editForm.head = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
export const update = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/dashboard/village-officials/{village_official}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
update.url = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { village_official: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    village_official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        village_official: args.village_official,
                }

    return update.definition.url
            .replace('{village_official}', parsedArgs.village_official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
update.put = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
update.patch = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
    const updateForm = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
        updateForm.put = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::update
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:94
 * @route '/dashboard/village-officials/{village_official}'
 */
        updateForm.patch = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:139
 * @route '/dashboard/village-officials/{village_official}'
 */
export const destroy = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/dashboard/village-officials/{village_official}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:139
 * @route '/dashboard/village-officials/{village_official}'
 */
destroy.url = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { village_official: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    village_official: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        village_official: args.village_official,
                }

    return destroy.definition.url
            .replace('{village_official}', parsedArgs.village_official.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:139
 * @route '/dashboard/village-officials/{village_official}'
 */
destroy.delete = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:139
 * @route '/dashboard/village-officials/{village_official}'
 */
    const destroyForm = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\Admin\VillageOfficialController::destroy
 * @see app/Http/Controllers/Admin/VillageOfficialController.php:139
 * @route '/dashboard/village-officials/{village_official}'
 */
        destroyForm.delete = (args: { village_official: string | number } | [village_official: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const villageOfficials = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
show: Object.assign(show, show),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default villageOfficials